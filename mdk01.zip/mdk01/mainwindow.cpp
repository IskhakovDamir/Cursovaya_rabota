#include "mainwindow.h"
#include "showinfowindow.h"
#include "ui_mainwindow.h"
#include "tvshowdatabase.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow),
    tvShowDatabase(new TVShowDatabase(this))
{
    ui->setupUi(this);

    this->setFixedSize(this->size());


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    ShowInfoWindow *infoWindow = new ShowInfoWindow(1);
    infoWindow->show();
}

void MainWindow::on_pushButton_2_clicked()
{
    ShowInfoWindow *infoWindow = new ShowInfoWindow(2);
    infoWindow->show();
}

void MainWindow::on_pushButton_3_clicked()
{
    ShowInfoWindow *infoWindow = new ShowInfoWindow(3);
    infoWindow->show();
}

void MainWindow::on_pushButton_4_clicked()
{
    ShowInfoWindow *infoWindow = new ShowInfoWindow(4); // Используем новый номер телеканала
    infoWindow->show();
}
