#include "showinfowindow.h"
#include "ui_showinfowindow.h"
#include "tvshowdatabase.h"
#include <QDateTime>

ShowInfoWindow::ShowInfoWindow(int channelNumber, QWidget *parent)
    : QDialog(parent),
    ui(new Ui::ShowInfoWindow),
    channelNumber(channelNumber)
{
    ui->setupUi(this);
    populateTable();
    ui->tableWidget->resizeColumnsToContents();

    // Создаем и настраиваем таймер для обновления времени
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &ShowInfoWindow::updateTime);
    timer->start(1000);  // Обновляем каждую секунду

    this->setFixedSize(this->size());
}

ShowInfoWindow::~ShowInfoWindow()
{
    delete ui;
}

void ShowInfoWindow::populateTable()
{
    TVShowDatabase tvShowDatabase;
    tvShowDatabase.populateTable(ui->tableWidget, channelNumber);
}

void ShowInfoWindow::updateTime()
{
    // Используем QDateTime для получения текущего времени и его форматирования
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QString timeText = currentDateTime.toString("hh:mm:ss");
    ui->currentTimeLabel->setText(timeText);
}
