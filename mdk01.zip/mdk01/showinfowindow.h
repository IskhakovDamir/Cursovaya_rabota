#ifndef SHOWINFOWINDOW_H
#define SHOWINFOWINDOW_H

#include <QDialog>
#include <QTableWidget>
#include <QTimer> // Добавлен заголовочный файл для таймера

namespace Ui {
class ShowInfoWindow;
}

class ShowInfoWindow : public QDialog
{
    Q_OBJECT

public:
    explicit ShowInfoWindow(int channelNumber, QWidget *parent = nullptr);
    ~ShowInfoWindow();

    void populateTable();

private slots:
    void updateTime(); // Добавлен слот для обновления времени

private:
    Ui::ShowInfoWindow *ui;
    int channelNumber;
    QTimer *timer; // Добавлен указатель на таймер
};

#endif // SHOWINFOWINDOW_H
