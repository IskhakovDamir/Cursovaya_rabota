#include "tvshowdatabase.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QDateTime>

TVShowDatabase::TVShowDatabase(QObject *parent)
    : QObject(parent)
{
    clearDatabase();  // Очищаем базу данных перед инициализацией
    initializeDatabase();
}

void TVShowDatabase::clearDatabase()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("tvshows.db");

    if (!db.open())
    {
        qDebug() << "Database Error: " << db.lastError().text();
        return;
    }

    QSqlQuery query;
    query.exec("DELETE FROM tvshows");
}

void TVShowDatabase::initializeDatabase()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("tvshows.db");

    if (!db.open()) {
        qDebug() << "Database Error: " << db.lastError().text();
        return;
    }

    QSqlQuery query;
    query.exec("CREATE TABLE IF NOT EXISTS tvshows ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT, "
               "channel INTEGER, "
               "channel_name TEXT, "
               "name TEXT, "
               "start_time TEXT, "
               "end_time TEXT)");

    // Вставляем тестовые данные
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Доброе утро', '05:00', '8:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Новости', '9:00', '9:19')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'АнтиФейк', '9:20', '9:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Жить здорово!', '10:00', '10:49')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Информационнный канал', '10:50', '11:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Новости', '12:00', '12:14')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Информационнный канал', '12:15', '14:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Новости', '15:00', '15:14')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Давай поженимся!', '15:15', '16:04')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Мужское/Женское', '16:05', '16:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Информационнный канал', '17:00', '17:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Вечерние новости', '18:00', '18:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Информационнный канал', '18:30', '19:54')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Куклы наследника Тутти', '19:55', '20:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Время', '21:00', '21:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Тест на беременность', '22:00', '22:54')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Большая игра', '22:55', '23:54')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (1, 'Первый канал', 'Машков', '23:55', '00:49')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Самые шокирующие гипотезы', '05:00', '05:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'С бодрым утром!', '06:00', '08:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Новости', '08:30', '08:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Военная тайна с Игорем Прокопенко', '09:00', '10:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Как устроен мир с Тимофеем Баженовым', '11:00', '11:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Информационная программа 112', '12:00', '12:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Новости', '12:30', '12:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Загадки человечества с Олегом Шишкиным', '13:00', '13:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Невероятно интересные истории', '14:00', '14:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Засекреченные списки', '15:00', '15:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Информационная программа 112', '16:00', '16:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Новости', '16:30', '16:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Тайны Чапман', '17:00', '17:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Самые шокирующие гипотезы', '18:00', '18:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Информационная программа 112', '19:00', '19:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Новости', '19:30', '19:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Одним меньше', '20:00', '22:14')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Водить по-русски', '22:15', '22:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Новости', '23:00', '23:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Документальный проект', '23:30', '00:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (2, 'РЕН ТВ', 'Рубикон', '00:30', '02:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Утро. Самое лучшее', '06:30', '07:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Сегодня', '08:00', '08:24')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Пес', '08:25', '09:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Сегодня', '10:00', '10:34')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Пес', '10:35', '12:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Сегодня', '13:00', '13:24')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'ЧП', '13:25', '13:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Место встречи', '14:00', '15:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Сегодня', '16:00', '16:44')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'За гранью', '16:45', '17:49')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'ДНК', '17:50', '18:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Сегодня', '19:00', '19:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Балабол', '20:00', '22:14')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'На стороне чувств', '22:15', '23:34')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Сегодня', '23:35', '23:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (3, 'НТВ', 'Медное солнце', '00:00', '04:49')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Студия Союз(16-я серия)', '05:05', '05:49')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Импровизация (128-я серия)', '05:50', '06:39')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Импровизация (129-я серия)', '06:40', '06:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Однажды в России (Спецдайджест)', '07:00', '07:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Однажды в России (Спецдайджест)', '08:00', '08:49')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Вызов (6-я серия)', '08:50', '09:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Новые Звезды в Африке (26-я серия)', '10:00', '12:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Бабушка легкого поведения 2.', '12:30', '14:09')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Прабабушка легкого поведения', '14:10', '15:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (1-я серия)', '16:00', '16:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (2-я серия)', '16:30', '16:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (3-я серия)', '17:00', '17:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (4-я серия)', '17:30', '17:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (5-я серия)', '18:00', '18:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (6-я серия)', '18:30', '18:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (7-я серия)', '19:00', '19:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (8-я серия)', '19:30', '19:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (9-я серия)', '20:00', '20:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Полярный (10-я серия)', '20:30', '20:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Соседка (8-я серия)', '21:00', '21:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Соседка (9-я серия)', '21:00', '21:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Однажды в России (267-я серия)', '22:00', '22:59')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Камеди Клаб (766-я серия)', '23:00', '00:04')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Лига городов (10-я серия)', '00:05', '01:39')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Импровизация. Команды (45-я серия)', '01:40', '02:29')");
    query.exec("INSERT INTO tvshows (channel, channel_name, name, start_time, end_time) VALUES (4, 'ТНТ', 'Импровизация. Команды (46-я серия)', '02:30', '03:14')");

}

void TVShowDatabase::populateTable(QTableWidget *tableWidget, int channelNumber)
{
// Очищаем таблицу перед заполнением
    tableWidget->clear();
    tableWidget->setColumnCount(4);
    tableWidget->setHorizontalHeaderLabels({"Телеканал", "Телепередача", "Время начала", "Время окончания"});

    // Выполняем запрос к базе данных
    QSqlQuery query;
    query.prepare("SELECT channel_name, name, start_time, end_time FROM tvshows WHERE channel = :channel");
    query.bindValue(":channel", channelNumber);

    if (query.exec())
    {
        int rowCount = 0;
        while (query.next())
        {
            tableWidget->setRowCount(rowCount + 1);  // Устанавливаем количество строк
            tableWidget->setItem(rowCount, 0, new QTableWidgetItem(query.value("channel_name").toString()));
            tableWidget->setItem(rowCount, 1, new QTableWidgetItem(query.value("name").toString()));
            tableWidget->setItem(rowCount, 2, new QTableWidgetItem(query.value("start_time").toString()));
            tableWidget->setItem(rowCount, 3, new QTableWidgetItem(query.value("end_time").toString()));
            ++rowCount;
        }
    }
    else
    {
        qDebug() << "Query Error: " << query.lastError().text();
    }
}



