#ifndef TVSHOWDATABASE_H
#define TVSHOWDATABASE_H

#include <QObject>
#include <QTableWidget>

class TVShowDatabase : public QObject
{
    Q_OBJECT
public:
    explicit TVShowDatabase(QObject *parent = nullptr);

    void initializeDatabase();
    void populateTable(QTableWidget *tableWidget, int channelNumber);

private:
    void clearDatabase(); // Добавлено объявление метода clearDatabase
    // Здесь вы можете добавить необходимые поля и методы для работы с базой данных
};

#endif // TVSHOWDATABASE_H
